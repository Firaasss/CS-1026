# Replace placeholders with correct Python

print("My first python code")
replace_1 = 46*2
replace_2 = 3+5

print(answer1)
print(answer2)

print("Everything works")
