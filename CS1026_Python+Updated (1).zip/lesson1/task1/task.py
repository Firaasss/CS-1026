# Replace placeholders with correct Python

function("I am learning Python")

