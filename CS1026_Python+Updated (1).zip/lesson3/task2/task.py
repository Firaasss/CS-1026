# Replace the '?'s with the correct boolean or relational operator to make all the statements True

a = 12
b = 7
t = True
c = 'e'

print((a > 0) boolean operator 1 (b > 0))

print(('a' > c) boolean operator 2 ('E' != c))

print((a % b != 0) and (b * 2 relational operator a))

print((t boolean operator 3 not(a > b)) and t)
