# Add statements to complete the program.

from datetime import datetime
hour = datetime.now().hour

if First condition:
    Assignment 1
elif Second condition:
    Assignment 2
else:
    Assignment 3

# Place your code here

print("Good {}, world".format(timeOfDay))
