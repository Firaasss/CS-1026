# Replace the placeholders and run the Python program.

x=5

# Is x > 5?
Type in the if-part
    print(Print a message when x is greater than 5)
else:
    print(Print a message when x is not greater than 5)
