# Replace the placeholders with code and run the Python program

class Coffee:
    def Define the header for the __add__ method:
        if Check to see if an object is in the class Cream:
            Add the return statement

class Cream:
    def __init__(self):
        self._percent=10


coffee = Coffee()
cream = Cream()

# Test the "add" method
print(coffee+cream)
