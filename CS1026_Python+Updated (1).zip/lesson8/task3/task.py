# Replace the placeholders with code to raise an exception and run the Python program

values =[1,2,3,4,5,"hello",6,7,8,9,"10"]

for cur in values:
    Insert the given print statement
    if type(values[cur]) == str:
        Raise an exception
