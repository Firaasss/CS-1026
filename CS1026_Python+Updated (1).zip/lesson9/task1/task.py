# Replace the placeholders with code and run the Python program

episode4 = {"Luke","Leia","Han","Chewie","C3PO","R2-D2","Vader","Greedo","Kenobi"}
episode5={"Luke","Leia","Han","Chewie","C3PO","R2-D2","Vader","Tauntaun","Yoda","Lando"}
episode6={"Luke","Leia","Han","Chewie","C3PO","R2-D2","Vader","Palpatine","Ackbar","Jabba","Rancor","Boba"}

# code for union under here call your set unEps
unEps = Compute the union of the three sets
print(unEps)


