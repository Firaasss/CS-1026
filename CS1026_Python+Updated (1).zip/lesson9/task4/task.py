# Replace the placeholders with code and run the Python program

name = ["Stirling","Lana","Cyril","Pam","Ray","Cheryl"]
alias =["Duchess","Truckasaurus","Chet","Cookie Monster","Gilles de Rais","Cherlene"]

Define a variable as an empty dictionary

for i in range(0,len(name)):
    Add pairs to the dictionary from the lists


for Loop through sorted dictionary:
    Print item and value

