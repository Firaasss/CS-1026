# Replace the placeholders with code and run the Python program

sentence ="I had such a horrible day. It was awful, so bad, sigh. It could not have been worse but actually though "\
          +"such a terrible horrible awful bad day."

makeItHappy ={"horrible":"amazing","bad":"good","awful":"awesome","worse":"better","terrible":"great"}

Split the sentence and assign to a variable
for word in Complete the range for the for:
    if Check to see if word is in makeItHappy list in makeItHappy:
        Replace old word with new one from makeItHappy

newString=""

Loop through words and make a sentence:
    newString = newString + word + " "

print(newString)

