# Replace the placeholders and run the Python program.

text = Open the file "text.txt" for reading
for Loop through each line of the file:
    print(Print each line)
text.close()

