# Replace the placeholders and complete the program.

text = open("text.txt","r")
myfile =open("myfile.txt","w")
line = Get the line
words = Split the line into separate words
for word in words:
    print(word)
    Write to file)

# Close the files
Close the file for text.txt
Close the file for myfile.txt
