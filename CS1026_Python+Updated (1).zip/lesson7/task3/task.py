# Replace the placeholders and complete the Python program.

f = open("filmdata.csv","r",encoding="utf-8")
for Process each line in the file:
    entries = Split into separate items
    if Test to see if year is earlier than 1990:
        print(Print year and film title)
f.close()
