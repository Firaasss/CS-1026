# Replace the placeholders and complete the Python program.

def zFirst(words):
    # We will need two lists
    zresult =[]
    result =[]
    for word in words:
        if Add test to determine if word begins with a 'z':
            # If it does, add it to the first list
            Add to list of z-words
        else:
            # Does not begin with a 'z'
            Append to other list

    Sort the list of z-words
    Sort the other list of words
    Define what to return

# Define a list of words
words=["hello","good","nice","as","at","baseball","absorb","sword","a","tall","so","bored","silver",
       "hi","pool","we","am","seven","do","you","want","ants","because","that's","how","you","get",
       "zebra","zealot","zoo","xylophone","asparagus"]

# Print the result of using zFirst
print(zFirst(words))

