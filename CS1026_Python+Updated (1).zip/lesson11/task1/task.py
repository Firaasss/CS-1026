# Replace the placeholders with code and run the Python program

# Define class Fruit
class Fruit():
    def Initialization statement 1
        Initialization statement 2"
        self._shape=""

    defDefine header for 'canBePhone' method):
        return "fruits can't be phones..."

# Define class Banana
Create the class definition header for the class Banana:
    def __init__(self):
        Define the initilization

    def Override the method:
        return "Ring ring ring ring ring ring ring banana phone\nBoop-boo-ba-doo-ba-doop"

apple=Fruit()
print(apple.canBePhone())
banana=Banana()
print(banana.canBePhone())
