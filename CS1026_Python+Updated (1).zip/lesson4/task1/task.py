# Replace the placeholder to complete the progam.

count = 1
While loop statement
    Statement to print count
    Add one to count

# Print the count
print(count)
