# Replace the placeholders to complete the Python program.

for Complete the rest of the for with a range:
    Print the loop variable
