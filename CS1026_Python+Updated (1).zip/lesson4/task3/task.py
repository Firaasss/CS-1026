# Replace the placeholders to complete the Python program.

Out for loop:
    for x in range(1,11):
        print(x)
