# Replace the placeholders and run the Python program

import random
name = input("Please enter your name: ")

for x Complete the for:
    print("test",x)
    ifFirst if test:
        print(name)
    if Second if test:
        print(random.randint(1,10))
