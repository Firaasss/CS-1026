# Replace the placeholders and complete the Python program.

def Define "helloWorld" function name and parameters:
    Add print statement

def helloWorldNTimes(n):
    Enter the for statement:
        Call "helloWorld"

# Include a "main" function
def main():
    helloWorldNTimes(7)

# Call the main function
main()
