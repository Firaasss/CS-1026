# Replace the placeholders to complete the Python program.

def addNumbersSpecify the parameters:
    result = Compute the sum
    return Return the sum

print(addNumbers(223,1235))
