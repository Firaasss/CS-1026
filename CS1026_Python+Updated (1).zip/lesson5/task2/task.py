# Replace the placeholders and complete the Python program.

def factorial(n):
    result = n
    for Complete the for loop statement:
        Compute a new result value
    return result

print(factorial(5))
print(factorial(7))
print(factorial(9))
