# Replace the placeholders and complete the Python program.

def isMultiple(n):
    ifComplete the if:
        return Specify what to return
    else:
        return Specify what to return here

def checkMultiples():
    for i in range(1,100):
        cur = isMultiple(i)
        if cur != -1:
            print(cur)

# Run the test
checkMultiples()
