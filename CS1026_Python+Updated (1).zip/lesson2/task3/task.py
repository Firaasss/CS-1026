# Try the following Python and answer the questions

print("CS" + "1026")
print("CS" + " "+ "1026")
print("CS "+"1026")
# notice the space differences

# for the print function you can also use the ','; try the following:
print(String 1,String 2)

# try your own
