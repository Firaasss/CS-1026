# Try the Python below and complete the placeholders.

x = 7
print(x)

y = x+5
print("x is {} and y is {}".format(x,y))

x = x+5
# Note the value changes when we do the statement above
print("x is now {}".format(x))

y = x+5
# If we repeat the second print what will we get?
print("x is {} and y is {}".format(x,y))

An assignment to a variable
Print the variable
