# Complete the placeholders in the following to finish the program

fDegrees = float(input("Please enter the Fahrenheit value: "))

# Convert to celsius
Variable for the celsius value = Expression to conver from F to C
print(Variable to print the answer)

