# Try the following Python and answer the questions

x=7
print(x+5)
print((x+5)*3)
print(x+5*3)
# Why are the last two different?

print(Add 1 to x and divide the sum by 4)

# Add your own!
