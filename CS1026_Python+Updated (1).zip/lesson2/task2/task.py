# Try the following Python and answer the questions

x = 2
print(2<5)
print(x<=2)
print(2!=5)
print(x==2)# 2 equals signs checks equality of something one equals sign is an assignment operator

#try printing 2=2
#delete the # in the line below to uncomment and test it
#print(2=2)

print(Add 3 to x and see if the sum is greater than 7)
#add your own!
