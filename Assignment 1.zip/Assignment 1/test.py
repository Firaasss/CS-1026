daysRented = input("Days: ")

import mat
