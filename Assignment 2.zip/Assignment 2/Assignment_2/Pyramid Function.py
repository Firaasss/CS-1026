def pyramidVolume(height, baseLength):
    baseArea = baseLength * baseLength


height = (input("Enter a height value: "))
baseLength = input("Enter a length for the base: ")

pyramidVolume(float(height, baseLength))
