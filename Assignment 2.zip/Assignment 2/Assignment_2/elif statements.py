elif inpShape == "quit":
    quit()
else:
    print("")
    print("Not a valid option. Valid options are 'cube', 'pyramid', 'ellipsoid', or 'quit'.")
    inpShape = input("Please enter a valid shape ('cube', 'pyramid', 'ellipsoid', or 'quit' to end) ")
